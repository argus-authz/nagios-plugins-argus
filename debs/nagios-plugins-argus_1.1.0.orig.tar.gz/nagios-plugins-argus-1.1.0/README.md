Nagios plugins for Argus (EMI)
==============================

General Information
-------------------
These probes work exclusively for Argus version 1.5.0 and onward

Documentation
-------------
The complete documentation of the probes can be found online:
    https://twiki.cern.ch/twiki/bin/view/EGEE/ArgusEMINagiosProbes


Installation
------------
Just type make install in the same directory as this README file can be found
